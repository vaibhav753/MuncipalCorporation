import '../Addcss/HomePage.css'

const ComplaintsCompletedList = () => {
    return(
        <div className="cent">
            <table className="table table-dark table-condensed table-bordered  " >
                <thead>
                <tr><th>Id</th><th>Type</th><th>Sub-Type</th><th>Action</th></tr>
                </thead>
                <tbody>
                    <tr><td></td><td></td><td></td><td></td></tr>
                    <tr><td></td><td></td><td></td><td></td></tr>
                    <tr><td></td><td></td><td></td><td></td></tr>
                    <tr><td></td><td></td><td></td><td></td></tr>
                    <tr><td></td><td></td><td></td><td></td></tr>
                    <tr><td></td><td></td><td></td><td></td></tr>
                    <tr><td></td><td></td><td></td><td></td></tr>
                </tbody>
            </table>
        </div>
    )
}

export default ComplaintsCompletedList;